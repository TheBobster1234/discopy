import { combineReducers } from 'redux';
import dm from './dm_notifications_reducer';

export default combineReducers({
  dm,
});